






<?php get_header(); ?>

<main class="main-content">
    <section class="hero-section" aria-label="メインビジュアル">
        <div id="mainVisualWrap" class="flex fadeInUp animated">
            <div id="mainVisual">
                <?php
                // ヒーロー画像はカスタムフィールドやメディアライブラリから取得
                $hero_image = get_option('dd_solutions_hero_image', get_template_directory_uri() . '/assets/img/top/mainimage.jpg');
                $hero_image_sp = get_option('dd_solutions_hero_image_sp', get_template_directory_uri() . '/assets/img/top/mainimage_sp.jpg');
                ?>
                <picture>
                    <source srcset="<?php echo esc_url($hero_image); ?>.avif" type="image/avif">
                    <source srcset="<?php echo esc_url($hero_image); ?>.webp" type="image/webp">
                    <img src="<?php echo esc_url($hero_image); ?>" alt="DD Solutions株式会社 ホームページ ヒーロー画像" class="pcONspOFF" width="1900" height="750" loading="lazy" decoding="async" fetchpriority="high">
                </picture>
                <picture>
                    <source srcset="<?php echo esc_url($hero_image_sp); ?>.avif" type="image/avif">
                    <source srcset="<?php echo esc_url($hero_image_sp); ?>.webp" type="image/webp">
                    <img src="<?php echo esc_url($hero_image_sp); ?>" alt="DD Solutions株式会社 ホームページ ヒーロー画像（スマートフォン）" class="pcOFFspON" width="640" height="938" loading="lazy" decoding="async" fetchpriority="high">
                </picture>
                <div class="mainCatch">
                    <div class="flex fadeInUp animated mb20" data-wow-delay="0.5s">
                        <p>家電IT周り<span class="fs80p">の</span>ホームドクター<br>
                        <span class="fs70p">家電<span class="fs90p">から</span>WEB制作開発<span class="fs90p">まで</span>ご相談ください。</span></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="bgNews" aria-label="新着情報">
    <div class="indexNews">
        <div class="newsLeft flex fadeInUp animated">
            <h2>News</h2>
        </div>
        <div class="contNews flex fadeInUp animated">
            <?php
            // announcements カスタム投稿タイプの新着情報を表示
            $announcements = get_posts(array(
                'numberposts' => 5,
                'post_type' => 'announcements',
                'orderby' => 'date',
                'order' => 'DESC'
            ));
            if ($announcements) :
            ?>
            <ul>
                <?php foreach ($announcements as $post) : setup_postdata($post); ?>
                <li>
                    <span class="date"><?php echo get_the_date('Y.m.d'); ?></span>
                    <span class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>
                </li>
                <?php endforeach; ?>
                <?php wp_reset_postdata(); ?>
            </ul>
            <?php else : ?>
            <ul>
                <li>
                    <span class="date">2025.04.17</span>
                    <span class="title">ホームページを公開いたしました。</span>
                </li>
            </ul>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="bgcolorTopBnr" aria-label="サービス紹介">
    <div class="f-wrap-HU">
        <div class="bnrPic3Box ratio-2_1 bnrGrid01 flex fadeInUp animated" data-wow-delay="0.1s">
            <div class="bnrPicInner">
                <div class="gridCenter">
                    <a href="<?php echo esc_url(home_url('/content1')); ?>">
                        家電販売・修理
                    </a>
                </div>
            </div>
        </div>
        <div class="bnrPic3Box ratio-2_1 bnrGrid02 flex fadeInUp animated" data-wow-delay="0.2s">
            <div class="bnrPicInner">
                <div class="gridCenter">
                    <a href="<?php echo esc_url(home_url('/content2')); ?>">
                        WEB・ソフトウェア開発
                    </a>
                </div>
            </div>
        </div>
        <div class="bnrPic3Box ratio-2_1 bnrGrid03 flex fadeInUp animated" data-wow-delay="0.3s">
            <div class="bnrPicInner">
                <div class="gridCenter">
                    <a href="<?php echo esc_url(home_url('/#anch01')); ?>">
                        会社案内
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="bgWhite flex fadeInUp animated" aria-label="お客様の思いに応えるサービス">
    <div class="wrapper">
        <h2>お客様の思いに応えるサービスを</h2>
        <div class="f-wrap-AC">
            <div class="f-item1-2 flex fadeInLeft animated">
                <p><img src="<?php echo get_template_directory_uri(); ?>/img/top/1.jpg" alt="" width="1000" height="625" loading="lazy" decoding="async"></p>
            </div>
            <div class="f-item1-2 flex fadeInRight animated">
                <ul class="liBox li1Div liCheck mgb1em">
                    <li>家電が故障したけど、どこに頼めばいいか分からない</li>
                    <li>古い家電の修理や部品交換を頼みたい</li>
                    <li>家電の調子が悪いので診てもらいたい</li>
                    <li>買い替え時に何を選べばいいか相談したい</li>
                    <li>地元で信頼できる家電の相談先を見つけたい</li>
                </ul>
                <p>DD Solutionsは、このようなお客様のお困りごと・ニーズに対応します。<br>当社代表は自衛隊上がりという経歴から、人に喜んでいただけることに生きがいを感じております。そんな思いをもとに「お客様第一主義」で、お客様の思いとニーズに寄り添ったサービスの提供ができるよう努めております。<br>これからもお客様が自然と笑顔になるサービスの提供を目指します。</p>
            </div>
        </div>
    </div>
</section>

<section class="bgColor flex fadeInUp animated" aria-label="代表挨拶">
    <div class="wrapper">
        <h2>代表挨拶</h2>
        <div class="f-wrap-AC f-row-reverse">
            <div class="f-item1-2 flex fadeInRight animated">
                <p><img src="<?php echo get_template_directory_uri(); ?>/img/top/2.jpg" alt="" width="1000" height="625" loading="lazy" decoding="async"></p>
            </div>
            <div class="f-item2-3 waterMleft flex fadeInLeft animated">
                <p class="mb10">当社は「お客様第一主義」を掲げ、地域の皆さまの暮らしとビジネスを技術で支えてまいりました。<br>家電修理とITサービスという異なる領域を一つの会社で提供できるのが私たちの強みです。<br>自衛隊出身という経験を活かし、責任感と誠実さをもって、今後も皆様の笑顔に貢献してまいります。</p>
                <p class="tar txtSign">DD Solutions株式会社<br>代表取締役　杉本 忍</p>
            </div>
        </div>
    </div>
</section>

<div id="anch01"></div>
<section class="bgTopad1 flex fadeInUp animated" aria-label="会社案内">
    <div class="wrapper">
        <h2>会社案内</h2>
        <div class="f-wrap-AC ">
            <div class="f-item1-2 flex ">
                <table class="table3Dot">
                    <tr>
                        <th>会社名</th>
                        <td>DD Solutions株式会社</td>
                    </tr>
                    <tr>
                        <th>代表</th>
                        <td>杉本 忍</td>
                    </tr>
                    <tr>
                        <th>所在地</th>
                        <td>〒150-0002 東京都渋谷区渋谷2丁目19番15号</td>
                    </tr>
                    <tr>
                        <th>事業内容</th>
                        <td>家電販売・修理<br>WEB・ソフトウェア開発<br><a href="https://msdigit.net/marrige/" target="_blank">結婚相談所</a></td>
                    </tr>
                </table>
            </div>
            <div class="f-item1-2 flex ">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3241.7065667268516!2d139.70118707471482!3d35.65960053116367!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x60188b585f2fb139%3A0xea165c22084c241b!2z44CSMTUwLTAwMDIg5p2x5Lqs6YO95riL6LC35Yy65riL6LC377yS5LiB55uu77yR77yZ4oiS77yR77yV!5e0!3m2!1sja!2sjp!4v1745470786178!5m2!1sja!2sjp" width="100%" height="500" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
</section>

<section class="bgTopad2 flex fadeInUp animated" aria-label="採用情報">
    <div class="wrapper">
        <h2>DD Solutionsで働きませんか？</h2>
        <div class="contPad70p txtPCcenterTabletLeft">
            <p class="mgb2em">私たちは、お客様の笑顔を大切にする仲間を求めています。<br>一緒に成長し、喜びを共有できる方をお待ちしています！</p>
            <div class="txtCenter">
                <p class="txtBnrAr"><a href="<?php echo esc_url(home_url('/career')); ?>">採用情報はこちら</a></p>
            </div>
        </div>
    </div>
</section>

</main>

<?php get_footer(); ?>






