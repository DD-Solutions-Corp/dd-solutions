



<?php
/**
 * Enqueue scripts and styles for DD Solutions Theme.
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Enqueue scripts and styles.
 */
function dd_solutions_enqueue_assets()
{
    // 共通CSS（最適化済み）
    $css_suffix = (defined('WP_ENV') && WP_ENV === 'production') ? '.min' : '';
    wp_enqueue_style('dd-solutions-common', get_template_directory_uri() . '/assets/css/common' . $css_suffix . '.css', array(), '1.0.0');
    
    // Font Awesome
    wp_enqueue_style('font-awesome', 'https://use.fontawesome.com/releases/v6.7.2/css/all.css', array('dd-solutions-common'), '6.7.2');
    
    // jQuery (from CDN)
    wp_deregister_script('jquery');
    wp_register_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js', array(), '2.2.4', true);
    wp_enqueue_script('jquery');
    
    // Font Awesome Kit
    wp_enqueue_script('font-awesome-kit', 'https://kit.fontawesome.com/4ca21661a0.js', array(), '6.7.2', false);
    
    // 共通JavaScript（最適化済み）
    $js_suffix = (defined('WP_ENV') && WP_ENV === 'production') ? '.min' : '';
    wp_enqueue_script('dd-solutions-main-js', get_template_directory_uri() . '/assets/js/main' . $js_suffix . '.js', array('jquery'), '1.0.0', true);
    
    // ページごとの条件分岐
    if (is_front_page() || is_home()) {
        // トップページ用追加CSS/JS（必要に応じて）
    }
    
    // コメント機能が有効な場合
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'dd_solutions_enqueue_assets');




