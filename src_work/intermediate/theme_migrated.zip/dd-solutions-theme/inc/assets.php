



<?php
/**
 * Enqueue scripts and styles for DD Solutions Theme.
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Enqueue scripts and styles.
 */
function dd_solutions_enqueue_assets()
{
    // Reset CSS
    wp_enqueue_style('dd-solutions-reset', get_template_directory_uri() . '/assets/css/reset.css', array(), '1.0.0');
    
    // Main CSS
    wp_enqueue_style('dd-solutions-main', get_template_directory_uri() . '/assets/css/main.css', array('dd-solutions-reset'), '1.0.0');
    
    // Animate CSS
    wp_enqueue_style('dd-solutions-animate', get_template_directory_uri() . '/assets/css/animate.css', array('dd-solutions-main'), '1.0.0');
    
    // Lightbox CSS
    wp_enqueue_style('dd-solutions-lightbox', get_template_directory_uri() . '/assets/css/lightbox.css', array('dd-solutions-animate'), '1.0.0');
    
    // Scroll hint CSS
    wp_enqueue_style('dd-solutions-scroll-hint', get_template_directory_uri() . '/assets/css/scroll-hint.css', array('dd-solutions-lightbox'), '1.0.0');
    
    // Add CSS
    wp_enqueue_style('dd-solutions-add', get_template_directory_uri() . '/assets/css/add.css', array('dd-solutions-scroll-hint'), '1.0.0');
    
    // Font Awesome
    wp_enqueue_style('font-awesome', 'https://use.fontawesome.com/releases/v6.7.2/css/all.css', array('dd-solutions-add'), '6.7.2');
    
    // jQuery (from CDN)
    wp_deregister_script('jquery');
    wp_register_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js', array(), '2.2.4', true);
    wp_enqueue_script('jquery');
    
    // Font Awesome Kit
    wp_enqueue_script('font-awesome-kit', 'https://kit.fontawesome.com/4ca21661a0.js', array(), '6.7.2', false);
    
    // Hamburger JS
    wp_enqueue_script('dd-solutions-hamburger', get_template_directory_uri() . '/assets/js/hamburger.js', array('jquery'), '1.0.0', true);
    
    // Match Height JS
    wp_enqueue_script('dd-solutions-match-height', get_template_directory_uri() . '/assets/js/jquery.matchHeight.js', array('jquery'), '1.0.0', true);
    wp_enqueue_script('dd-solutions-js-match-height', get_template_directory_uri() . '/assets/js/js-matchHeight.js', array('dd-solutions-match-height'), '1.0.0', true);
    
    // Lightbox JS
    wp_enqueue_script('dd-solutions-lightbox-js', get_template_directory_uri() . '/assets/js/lightbox.js', array('jquery'), '1.0.0', true);
    
    // Top button JS
    wp_enqueue_script('dd-solutions-topbtn', get_template_directory_uri() . '/assets/js/topbtn.js', array('jquery'), '1.0.0', true);
    
    // Main JS
    wp_enqueue_script('dd-solutions-5-1-1', get_template_directory_uri() . '/assets/js/5-1-1.js', array('jquery'), '1.0.0', true);
    
    // Scroll hint JS
    wp_enqueue_script('dd-solutions-scroll-hint-js', get_template_directory_uri() . '/assets/js/scroll-hint.js', array('jquery'), '1.0.0', true);
    
    // Accordion JS
    wp_enqueue_script('dd-solutions-accordion', get_template_directory_uri() . '/assets/js/accordion.js', array('jquery'), '1.0.0', true);
    
    // WOW JS
    wp_enqueue_script('dd-solutions-wow', get_template_directory_uri() . '/assets/js/wow.min.js', array('jquery'), '1.0.0', true);
    wp_enqueue_script('dd-solutions-wow-animated', get_template_directory_uri() . '/assets/js/wow_animated.js', array('dd-solutions-wow'), '1.0.0', true);
    
    // Scroll class JS
    wp_enqueue_script('dd-solutions-scroll-class', get_template_directory_uri() . '/assets/js/scroll-class.js', array('jquery'), '1.0.0', true);
    
    // ページごとの条件分岐
    if (is_front_page() || is_home()) {
        // トップページ用追加CSS/JS（必要に応じて）
    }
    
    // コメント機能が有効な場合
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'dd_solutions_enqueue_assets');




