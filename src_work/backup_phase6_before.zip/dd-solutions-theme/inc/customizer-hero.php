<?php
if (!defined("ABSPATH")) exit;

add_action("customize_register", function($wp_customize) {
    $wp_customize->add_section("dd_hero_slider", [
        "title" => "ヒーロースライダー設定",
        "priority" => 30,
    ]);
    
    $wp_customize->add_setting("hero_slider_images", [
        "default" => json_encode([
            ["pc" => get_template_directory_uri()."/assets/img/top/mainimage.jpg", "sp" => get_template_directory_uri()."/assets/img/top/mainimage_sp.jpg"]
        ]),
        "sanitize_callback" => "sanitize_text_field"
    ]);
    
    $wp_customize->add_control("hero_slider_images", [
        "label" => "スライダー画像（JSON形式）",
        "section" => "dd_hero_slider",
        "type" => "textarea",
        "description" => "例: [{\"pc\":\"URL1\",\"sp\":\"URL2\"}]"
    ]);
});

add_filter("wp_generate_attachment_metadata", function($metadata, $attachment_id) {
    $file = get_attached_file($attachment_id);
    if (!file_exists($file)) return $metadata;
    
    $info = pathinfo($file);
    if (!in_array(strtolower($info["extension"]), ["jpg","jpeg","png"])) return $metadata;
    
    $img = wp_get_image_editor($file);
    if (is_wp_error($img)) return $metadata;
    
    $webp = $info["dirname"]."/".$info["filename"].".webp";
    if (!file_exists($webp)) {
        $img->save($webp, "image/webp");
    }
    
    if (function_exists("imageavif")) {
        $avif = $info["dirname"]."/".$info["filename"].".avif";
        if (!file_exists($avif)) {
            $img->save($avif, "image/avif");
        }
    }
    
    return $metadata;
}, 10, 2);
