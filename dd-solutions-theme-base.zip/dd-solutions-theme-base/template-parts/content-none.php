<section class="no-results not-found">
  <h2>見つかりませんでした</h2>
  <p>条件を変えて再度お試しください。</p>
  <?php get_search_form(); ?>
</section>