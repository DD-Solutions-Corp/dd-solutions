<?php
if (!defined('ABSPATH')) exit;

// 新着情報設定（投稿タイプをチェックボックスで選択）
add_action('customize_register', function($wp_customize) {
    $wp_customize->add_section('dd_news_settings', [
        'title' => '新着情報設定',
        'priority' => 35,
    ]);
    
    // 利用可能な投稿タイプを取得
    $post_types = get_post_types(['public' => true], 'objects');
    $choices = [];
    foreach ($post_types as $pt) {
        if ($pt->name !== 'attachment' && $pt->name !== 'page') {
            $choices[$pt->name] = $pt->label;
        }
    }
    
    $wp_customize->add_setting('news_post_types', [
        'default' => 'post',
        'sanitize_callback' => 'sanitize_text_field'
    ]);
    
    $wp_customize->add_control('news_post_types', [
        'label' => '表示する投稿タイプ',
        'section' => 'dd_news_settings',
        'type' => 'select',
        'choices' => $choices,
        'description' => '複数選択する場合はカンマ区切りで入力: post,announcements'
    ]);
    
    $wp_customize->add_setting('news_post_count', ['default' => 5]);
    $wp_customize->add_control('news_post_count', [
        'label' => '表示件数',
        'section' => 'dd_news_settings',
        'type' => 'number',
        'input_attrs' => ['min'=>1,'max'=>20]
    ]);
});
