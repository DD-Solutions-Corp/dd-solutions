
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="format-detection" content="telephone=no">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header id="headWrap" class="site-header">
  <div id="headContent">
    <div class="logoArea">
      <?php
      if (function_exists('the_custom_logo') && has_custom_logo()) {
        the_custom_logo();
      } else {
        echo '<h1><a href="' . esc_url(home_url('/')) . '"><img src="' . get_template_directory_uri() . '/assets/img/header/logo.png" alt="' . get_bloginfo('name') . '" width="200" height="60" loading="eager"></a></h1>';
      }
      ?>
    </div>
    <div class="pcNaviWrap">
      <div class="inner">
        <nav class="NavMenu pcNavi" aria-label="Primary">
          <?php
          wp_nav_menu([
            'theme_location' => 'primary',
            'container'      => false,
            'menu_class'     => '',
            'fallback_cb'    => function() {
              echo '<ul>';
              echo '<li><a href="' . esc_url(home_url('/')) . '">ホーム</a></li>';
              echo '<li><a href="' . esc_url(home_url('/products')) . '">家電販売・修理</a></li>';
              echo '<li><a href="' . esc_url(home_url('/services')) . '">WEB・ソフトウェア開発</a></li>';
              echo '<li><a href="' . esc_url(home_url('/news')) . '">新着情報</a></li>';
              echo '<li class="liContact"><a href="' . esc_url(home_url('/contact')) . '"><i class="fas fa-envelope"></i>&nbsp;お問い合わせ</a></li>';
              echo '</ul>';
            }
          ]);
          ?>
        </nav>
        <div class="Toggle">
          <span class="toggle-span"></span>
          <span></span>
          <span></span>
          <p>MENU</p>
        </div>
      </div>
    </div>
  </div>
  <div class="contactAreaTab">
    <p class="bnrContact">
      <a href="<?php echo esc_url(home_url('/contact')); ?>">
        <i class="fas fa-envelope-square"></i>
      </a>
    </p>
  </div>
</header>
