
new ScrollHint('.tableScrollTablet', {
suggestiveShadow: true,
remainingTime: 5000,
i18n: {
scrollable: 'スクロールできます'
}
});

new ScrollHint('.tableScrollSp', {
suggestiveShadow: true,
remainingTime: 5000,
i18n: {
scrollable: 'スクロールできます'
}
});

