// front-page specific scripts (placeholder)
