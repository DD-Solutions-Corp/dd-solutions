//jQuery transitions init(wow + animated)
wow = new WOW(
    {
        boxClass: 'flex',
        animateClass: 'animated', // default
        offset: 0,          // default
        mobile: true,       // default
        live: true        // default
    }
    )
wow.init();
