<?php
if (!defined("ABSPATH")) exit;

add_action("customize_register", function($wp_customize) {
    $wp_customize->add_section("dd_contact_form", [
        "title" => "お問い合わせフォーム設定",
        "priority" => 40,
    ]);
    
    $wp_customize->add_setting("contact_email", ["default" => get_option("admin_email")]);
    $wp_customize->add_control("contact_email", [
        "label" => "送信先メールアドレス",
        "section" => "dd_contact_form",
        "type" => "email"
    ]);
    
    $wp_customize->add_setting("contact_success_msg", ["default" => "お問い合わせありがとうございます。"]);
    $wp_customize->add_control("contact_success_msg", [
        "label" => "送信完了メッセージ",
        "section" => "dd_contact_form",
        "type" => "textarea"
    ]);
});

add_action("wp_ajax_dd_contact_submit", "dd_handle_contact_form");
add_action("wp_ajax_nopriv_dd_contact_submit", "dd_handle_contact_form");

function dd_handle_contact_form() {
    check_ajax_referer("dd_contact_nonce", "nonce");
    
    $name = sanitize_text_field($_POST["name"] ?? "");
    $email = sanitize_email($_POST["email"] ?? "");
    $phone = sanitize_text_field($_POST["phone"] ?? "");
    $message = sanitize_textarea_field($_POST["message"] ?? "");
    
    if (empty($name) || empty($email) || empty($message)) {
        wp_send_json_error(["message" => "必須項目を入力してください。"]);
    }
    
    $to = get_theme_mod("contact_email", get_option("admin_email"));
    $subject = "【お問い合わせ】" . $name . "様より";
    $body = "お名前: {$name}\nメール: {$email}\n電話: {$phone}\n\n{$message}";
    $headers = ["Content-Type: text/plain; charset=UTF-8"];
    
    if (wp_mail($to, $subject, $body, $headers)) {
        wp_send_json_success(["message" => get_theme_mod("contact_success_msg", "お問い合わせありがとうございます。")]);
    } else {
        wp_send_json_error(["message" => "送信に失敗しました。"]);
    }
}
