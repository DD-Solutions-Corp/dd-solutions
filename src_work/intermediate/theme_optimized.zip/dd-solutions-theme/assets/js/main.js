








// 共通JavaScript
document.addEventListener('DOMContentLoaded', function() {
	
	// ページトップボタン
	const pagetop = document.getElementById('pagetop');
	if (pagetop) {
		pagetop.addEventListener('click', function(e) {
			e.preventDefault();
			window.scrollTo({
				top: 0,
				behavior: 'smooth'
			});
		});
		
		// スクロール時に表示/非表示
		window.addEventListener('scroll', function() {
			if (window.pageYOffset > 300) {
				pagetop.style.display = 'block';
			} else {
				pagetop.style.display = 'none';
			}
		});
	}
	
	// ハンバーガーメニュー
	const toggle = document.querySelector('.Toggle');
	const navMenu = document.querySelector('.NavMenu');
	if (toggle && navMenu) {
		toggle.addEventListener('click', function() {
			navMenu.classList.toggle('active');
			toggle.classList.toggle('active');
		});
	}
	
	// スクロールクラス
	window.addEventListener('scroll', function() {
		const sections = document.querySelectorAll('section');
		sections.forEach(function(section) {
			const sectionTop = section.getBoundingClientRect().top;
			const sectionHeight = section.offsetHeight;
			
			if (sectionTop - window.innerHeight <= 0 && sectionTop + sectionHeight >= 0) {
				section.classList.add('in-view');
			}
		});
	});
	
	// フォームの電話番号リンク
	const telLinks = document.querySelectorAll('a[href^="tel:"]');
	telLinks.forEach(function(link) {
		link.addEventListener('click', function(e) {
			if (!confirm('電話をかけますか？')) {
				e.preventDefault();
			}
		});
	});
	
});








