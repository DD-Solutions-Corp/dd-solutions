<?php
/**
 * Template Name: 新着情報一覧
 */
get_header();
?>
<div id="pageTitleMover">
  <div id="pageTitle" class="content3Tit">
    <div id="pth1Wrap" class="bgWhite flex fadeInUp animated">
      <h1>新着情報</h1>
    </div>
  </div>
</div>
</div>
<main>
  <article>
    <section class="bgWhite flex fadeInUp animated">
      <div class="wrapper">
        <div class="news-filter">
          <select id="newsFilter">
            <option value="">全て</option>
            <option value="post">投稿</option>
            <option value="announcements">お知らせ</option>
          </select>
        </div>
        
        <div class="news-list">
          <?php
          $types_str = get_theme_mod('news_post_types', 'post');
          $types = array_map('trim', explode(',', $types_str));
          $count = (int) get_theme_mod('news_post_count', 10);
          
          $q = new WP_Query([
            'post_type' => $types,
            'posts_per_page' => $count,
            'paged' => 1
          ]);
          
          if ($q->have_posts()) :
            while ($q->have_posts()) : $q->the_post();
          ?>
            <div class="news-item">
              <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
              <p class="date"><?php echo get_the_date('Y.m.d'); ?></p>
              <div class="excerpt"><?php the_excerpt(); ?></div>
            </div>
          <?php
            endwhile;
            wp_reset_postdata();
          endif;
          ?>
        </div>
      </div>
    </section>
  </article>
</main>
<?php get_footer(); ?>
