

<?php
/**
 * DD Solutions Theme functions and definitions
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function dd_solutions_theme_setup()
{
    // Add default posts and comments RSS feed links to head.
    add_theme_support('automatic-feed-links');

    // Let WordPress manage the document title.
    add_theme_support('title-tag');

    // Enable support for Post Thumbnails on posts and pages.
    add_theme_support('post-thumbnails');

    // Enable support for custom logo.
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
        'header-text' => array('site-title', 'site-description'),
    ));

    // Add theme support for HTML5.
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));

    // Register navigation menus.
    register_nav_menus(array(
        'primary' => __('Main Menu', 'dd-solutions'),
        'footer'  => __('Footer Menu', 'dd-solutions'),
    ));
}
add_action('after_setup_theme', 'dd_solutions_theme_setup');

/**
 * Minify CSS and JS files for production
 */
function dd_solutions_minify_assets() {
    if (!defined('WP_ENV') || WP_ENV !== 'production') {
        return;
    }
    
    // CSS minify
    $css_files = array(
        'common.css' => 'common.min.css'
    );
    
    foreach ($css_files as $source => $minified) {
        $source_path = get_template_directory() . '/assets/css/' . $source;
        $minified_path = get_template_directory() . '/assets/css/' . $minified;
        
        if (file_exists($source_path)) {
            if (!file_exists($minified_path) || filemtime($source_path) > filemtime($minified_path)) {
                $css_content = file_get_contents($source_path);
                $minified_css = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css_content);
                $minified_css = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $minified_css);
                file_put_contents($minified_path, $minified_css);
            }
        }
    }
    
    // JS minify
    $js_files = array(
        'main.js' => 'main.min.js'
    );
    
    foreach ($js_files as $source => $minified) {
        $source_path = get_template_directory() . '/assets/js/' . $source;
        $minified_path = get_template_directory() . '/assets/js/' . $minified;
        
        if (file_exists($source_path)) {
            if (!file_exists($minified_path) || filemtime($source_path) > filemtime($minified_path)) {
                $js_content = file_get_contents($source_path);
                $minified_js = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $js_content);
                $minified_js = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $minified_js);
                file_put_contents($minified_path, $minified_js);
            }
        }
    }
}
add_action('admin_init', 'dd_solutions_minify_assets');

/**
 * Load required files.
 */
require_once get_template_directory() . '/inc/assets.php';

