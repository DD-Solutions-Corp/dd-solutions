
<?php
/**
 * テーマ基本設定・アセット読込（日本語コメント）
 * - CSS/JSの確実な読込
 * - メニュー登録
 * - キャッシュバスター（filemtime）
 * - HTML5サポート
 */
add_action('after_setup_theme', function () {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('custom-logo');
  add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption','style','script']);
  register_nav_menus([
    'primary' => 'Primary Menu',
    'footer'  => 'Footer Menu',
  ]);
});

// filemtimeでキャッシュバスターを付与
function dd_ver($rel) {
  $abs = get_theme_file_path($rel);
  return file_exists($abs) ? filemtime($abs) : null;
}

add_action('wp_enqueue_scripts', function () {
  // 共通CSS（minがあれば優先）
  $common = file_exists(get_theme_file_path('/assets/css/common.min.css'))
          ? '/assets/css/common.min.css' : '/assets/css/common.css';
  wp_enqueue_style('dd-common', get_theme_file_uri($common), [], dd_ver($common));

  // ページ別CSS
  if (is_front_page()) {
    $home = file_exists(get_theme_file_path('/assets/css/home.min.css'))
          ? '/assets/css/home.min.css' : '/assets/css/home.css';
    if (file_exists(get_theme_file_path($home))) {
      wp_enqueue_style('dd-home', get_theme_file_uri($home), ['dd-common'], dd_ver($home));
    }
  }

  // 共通JS（フッター）
  $main_js = file_exists(get_theme_file_path('/assets/js/main.min.js'))
           ? '/assets/js/main.min.js' : '/assets/js/main.js';
  if (file_exists(get_theme_file_path($main_js))) {
    wp_enqueue_script('dd-main', get_theme_file_uri($main_js), [], dd_ver($main_js), true);
  }
  // ナビ用など追加があればここに（存在確認付き）
  $nav_js = file_exists(get_theme_file_path('/assets/js/nav.js')) ? '/assets/js/nav.js' : null;
  if ($nav_js) wp_enqueue_script('dd-nav', get_theme_file_uri($nav_js), ['dd-main'], dd_ver($nav_js), true);
}, 20);

// カスタマイザー：トップの新着情報（投稿タイプ/件数）設定
add_action('customize_register', function ($wp_customize) {
  $wp_customize->add_section('dd_news_section', [
    'title'       => '新着情報の設定',
    'description' => 'トップページの新着情報に表示する投稿タイプと件数を指定します。',
    'priority'    => 160,
  ]);
  // 投稿タイプ
  $wp_customize->add_setting('news_post_type', ['default' => 'post']);
  $wp_customize->add_control('news_post_type', [
    'label'   => '投稿タイプ',
    'section' => 'dd_news_section',
    'type'    => 'select',
    'choices' => ['post'=>'通常の投稿','announcements'=>'お知らせ(カスタム投稿)']
  ]);
  // 件数
  $wp_customize->add_setting('news_post_count', ['default' => 5]);
  $wp_customize->add_control('news_post_count', [
    'label'   => '表示件数',
    'section' => 'dd_news_section',
    'type'    => 'number',
    'input_attrs' => ['min'=>1,'max'=>20]
  ]);
});
